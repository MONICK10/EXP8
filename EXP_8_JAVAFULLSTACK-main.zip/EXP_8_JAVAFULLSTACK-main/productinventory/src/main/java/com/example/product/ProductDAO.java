package com.example.product;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProductDAO {

    public void addProduct(Product product) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.persist(product);

            transaction.commit();

            System.out.println("Product added successfully.");

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            e.printStackTrace();
        }
    }
    public Product getProduct(int id) {

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            return session.get(Product.class, id);

        } catch (Exception e) {

            e.printStackTrace();
            return null;
        }
    }
    public void updateProduct(Product product) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.merge(product);

            transaction.commit();

            System.out.println("Product updated successfully.");

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            e.printStackTrace();
        }
    }
    public void deleteProduct(int id) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            Product product = session.get(Product.class, id);

            if (product != null) {

                session.remove(product);

                System.out.println("Product deleted successfully.");

            } else {

                System.out.println("Product not found.");
            }

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            e.printStackTrace();
        }
    }
}